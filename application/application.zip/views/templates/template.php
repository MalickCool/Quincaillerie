<?php
/**
 * Created by PhpStorm.
 * User: GLORIA TECHNOLOGY
 * Date: 11/02/2019
 * Time: 16:03
 */

$this->load->view('templates/header');
$this->load->view('templates/navbar');
$this->load->view($page);
$this->load->view('templates/footer');